---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

## Describe the feature
Describe the feature you requested...

## Which edition of ReoGrid is targeted
- Windows Form
- WPF
